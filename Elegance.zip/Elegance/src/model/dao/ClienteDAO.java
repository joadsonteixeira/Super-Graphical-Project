/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;
import java.util.logging.Level;
import javax.swing.JOptionPane;
import connection.ConnectionFactory;
import model.bin.Cliente;

/**
 *
 * @author Joadson
 */
public class ClienteDAO {
    
    Connection con;
    
//    public ClienteDAO() {
//        con = ConnectionFactory();
//        JOptionPane.showMessageDialog(null, "Conexão bem sucedida");
//    }
    
    public void create(Cliente c) {
        
        con = ConnectionFactory.getConnection();

        PreparedStatement stmt = null;

        try {
            System.out.println("trying");
            
            stmt = con.prepareStatement("INSERT INTO clientes (nome,endereco, cidade, uf, telefone, email)VALUES(?,?,?,?,?,?)");
            stmt.setString(1, c.getNome());
            stmt.setString(2, c.getEndereco());
            stmt.setString(3, c.getCidade());
            stmt.setString(4, c.getUf());
            stmt.setString(5, c.getTelefone());
            stmt.setString(6, c.getEmail());
            //stmt.setString(7, c.getDataNascimento());
            

            stmt.executeUpdate();

            JOptionPane.showMessageDialog(null, "Salvo com sucesso!");
        } catch (SQLException ex) {
            System.out.println(ex);
        } finally {
            ConnectionFactory.closeConnection(con, stmt);
        }
        ConnectionFactory.closeConnection(con);
    }
    
}
