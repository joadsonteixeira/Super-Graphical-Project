/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;
import java.util.logging.Level;
import javax.swing.JOptionPane;
import connection.ConnectionFactory;
import model.bin.Cliente;

/**
 *
 * @author Joadson
 */
public class ClienteDAO {
    Connection con;
    
    
    public ClienteDAO() {
        con = ConnectionFactory.getConnection();
    }
    
    public void create(Cliente c) {
        
        con = ConnectionFactory.getConnection();

        PreparedStatement stmt = null;

        try {
            stmt = con.prepareStatement("INSERT INTO clientes (nome, dt_nasc, cpf, endereco, bairro, cidade, uf, telefone, email)VALUES(?,?,?,?,?,?,?,?,?)");
            stmt.setString(1, c.getNome());
            stmt.setString(2, c.getDataNascimento());
            stmt.setString(3, c.getCpf());
            stmt.setString(4, c.getEndereco());
            stmt.setString(5, c.getBairro());
            stmt.setString(6, c.getCidade());
            stmt.setString(7, c.getUf());
            stmt.setString(8, c.getTelefone());
            stmt.setString(9, c.getEmail());
            

            stmt.executeUpdate();

            JOptionPane.showMessageDialog(null, "Salvo com sucesso!");
        } catch (SQLException ex) {
            System.out.println(ex);
        } finally {
            ConnectionFactory.closeConnection(con, stmt);
        }
        ConnectionFactory.closeConnection(con);
    }
    
    public void delete(Cliente c) {

        PreparedStatement stmt = null;

        try {
            stmt = con.prepareStatement("DELETE FROM cabelos WHERE idClientes = ?");
            stmt.setInt(1, c.getIdCliente());

            stmt.executeUpdate();

            JOptionPane.showMessageDialog(null, "Excluido com sucesso!");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao excluir: " + ex);
        } finally {
            ConnectionFactory.closeConnection(con, stmt);
        }

    }
    
    public void delete(int id) {

        PreparedStatement stmt = null;

        try {
            stmt = con.prepareStatement("DELETE FROM clientes WHERE idClientes = ?");
            stmt.setInt(1, id);

            stmt.executeUpdate();

            JOptionPane.showMessageDialog(null, "Excluido com sucesso!");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao excluir: " + ex);
        } finally {
            ConnectionFactory.closeConnection(con, stmt);
        }

    }
}
