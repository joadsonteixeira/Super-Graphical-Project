package model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;
import java.util.logging.Level;
import javax.swing.JOptionPane;
import connection.ConnectionFactory;
import model.bin.Cabelo;


public class CabeloDAO {
	
	Connection con;
    
    public CabeloDAO() {
        con = ConnectionFactory.getConnection();
    }
    
    public void create(Cabelo c) {

        PreparedStatement stmt = null;

        try {
            stmt = con.prepareStatement("INSERT INTO cabelos (quant_estoque,quant_minima, preco_compra, preco_venda, modelo, cor, tamanho_cm)VALUES(?,?,?,?,?,?,?)");
            stmt.setInt(1, c.getQntEstoque());
            stmt.setInt(2, c.getQntMinima());
            stmt.setDouble(3, c.getPrecoCompra());
            stmt.setDouble(4, c.getPrecoVenda());
            stmt.setString(5, c.getModelo());
            stmt.setString(6, c.getCor());
            stmt.setDouble(7, c.getTam());
            

            stmt.executeUpdate();

            JOptionPane.showMessageDialog(null, "Salvo com sucesso!");
        } catch (SQLException ex) {
            System.out.println(ex);
        } finally {
            ConnectionFactory.closeConnection(con, stmt);
        }

    }

    public List<Cabelo> read() {

        PreparedStatement stmt = null;
        ResultSet rs = null;

        List<Cabelo> cabelos = new ArrayList<>();

        try {
            stmt = con.prepareStatement("SELECT * FROM cabelos");
            rs = stmt.executeQuery();

            while (rs.next()) {

            	Cabelo cabelo = new Cabelo();

            	cabelo.setIdCabelo(rs.getInt("idCabelos"));
            	cabelo.setQntEstoque(rs.getInt("quant_estoque"));
            	cabelo.setQntMinima(rs.getInt("quant_minima"));
            	cabelo.setPrecoCompra(rs.getDouble("preco_compra"));
            	cabelo.setPrecoVenda(rs.getDouble("preco_venda"));
            	cabelo.setModelo(rs.getString("modelo"));
            	cabelo.setCor(rs.getString("cor"));
            	cabelo.setTam(rs.getDouble("tamanho_cm"));
                cabelos.add(cabelo);
            }

        } catch (SQLException ex) {
            Logger.getLogger(CabeloDAO.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            ConnectionFactory.closeConnection(con, stmt, rs);
        }

        return cabelos;

    }
    public List<Cabelo> readForModel(String model) {

        PreparedStatement stmt = null;
        ResultSet rs = null;

        List<Cabelo> cabelos = new ArrayList<>();

        try {
            stmt = con.prepareStatement("SELECT * FROM cabelos WHERE modelo LIKE ?");
            stmt.setString(1, "%"+model+"%");
            
            rs = stmt.executeQuery();

            while (rs.next()) {

            	Cabelo cabelo = new Cabelo();

            	cabelo.setIdCabelo(rs.getInt("idCabelos"));
            	cabelo.setQntEstoque(rs.getInt("quant_estoque"));
            	cabelo.setQntMinima(rs.getInt("quant_minima"));
            	cabelo.setPrecoCompra(rs.getDouble("preco_compra"));
            	cabelo.setPrecoVenda(rs.getDouble("preco_venda"));
            	cabelo.setModelo(rs.getString("modelo"));
            	cabelo.setCor(rs.getString("cor"));
            	cabelo.setTam(rs.getDouble("tamanho_cm"));
                cabelos.add(cabelo);
            }

        } catch (SQLException ex) {
            Logger.getLogger(CabeloDAO.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            ConnectionFactory.closeConnection(con, stmt, rs);
        }

        return cabelos;

    }

    public void update(Cabelo c) {

        PreparedStatement stmt = null;

        try {
            stmt = con.prepareStatement("UPDATE cabelos SET quant_estoque = ?,quant_minima = ?, preco_compra = ?, preco_venda = ?, modelo = ?, cor = ?, tamanho_cm = ?  WHERE idCabelos = ?");
            stmt.setInt(1, c.getQntEstoque());
            stmt.setInt(2, c.getQntMinima());
            stmt.setDouble(3, c.getPrecoCompra());
            stmt.setDouble(4, c.getPrecoVenda());
            stmt.setString(5, c.getModelo());
            stmt.setString(6, c.getCor());
            stmt.setDouble(7, c.getTam());
            stmt.setInt(8, c.getIdCabelo());

            stmt.executeUpdate();

            JOptionPane.showMessageDialog(null, "Atualizado com sucesso!");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao atualizar: " + ex);
        } finally {
            ConnectionFactory.closeConnection(con, stmt);
        }

    }
    public void delete(Cabelo c) {

        PreparedStatement stmt = null;

        try {
            stmt = con.prepareStatement("DELETE FROM cabelos WHERE idCabelos = ?");
            stmt.setInt(1, c.getIdCabelo());

            stmt.executeUpdate();

            JOptionPane.showMessageDialog(null, "Excluido com sucesso!");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao excluir: " + ex);
        } finally {
            ConnectionFactory.closeConnection(con, stmt);
        }

    }


}
