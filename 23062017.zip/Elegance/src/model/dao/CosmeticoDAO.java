package model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;
import java.util.logging.Level;
import javax.swing.JOptionPane;
import connection.ConnectionFactory;
import model.bin.Cabelo;
import model.bin.Cosmetico;


public class CosmeticoDAO {
	
	Connection con;
    
    public CosmeticoDAO() {
        con = ConnectionFactory.getConnection();
    }
    
    public void create(Cosmetico c) {

        PreparedStatement stmt = null;

        try {
            stmt = con.prepareStatement("INSERT INTO cosmeticos (nome_cosmetico,marca, preco_venda, preco_compra, volume, qnt_min)VALUES(?,?,?,?,?,?)");
            stmt.setString(1, c.getNome());
            stmt.setString(2, c.getMarca());
            stmt.setDouble(3, c.getPrecoVenda());
            stmt.setDouble(4, c.getPrecoCompra());
            stmt.setDouble(5, c.getVolume());
            stmt.setInt(6, c.getQntMinima());
            

            stmt.executeUpdate();

            JOptionPane.showMessageDialog(null, "Salvo com sucesso!");
        } catch (SQLException ex) {
            System.out.println(ex);
        } finally {
            ConnectionFactory.closeConnection(con, stmt);
        }

    }
    
     public void delete(int id) {

        PreparedStatement stmt = null;

        try {
            stmt = con.prepareStatement("DELETE FROM cosmeticos WHERE idCosmetico = ?");
            stmt.setInt(1, id);

            stmt.executeUpdate();

            JOptionPane.showMessageDialog(null, "Excluido com sucesso!");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao excluir: " + ex);
        } finally {
            ConnectionFactory.closeConnection(con, stmt);
        }

    }
}
