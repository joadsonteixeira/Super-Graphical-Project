/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import connection.ConnectionFactory;
import model.bin.Servico;

/**
 *
 * @author Lucas
 */
public class ServicoDAO {
    Connection con;
    
    
    public ServicoDAO() {
        con = ConnectionFactory.getConnection();
    }
    
    public void create(Servico s) throws SQLException {
       
        con = ConnectionFactory.getConnection();
        PreparedStatement stmt = null;
        
        try { 
            
            stmt = con.prepareStatement ("INSERT INTO servicos (nome_serv, valor_serv, descricao, usa_cabelo)VALUES(?,?,?,?)");
            stmt.setString(1, s.getNome());
            stmt.setDouble(2, s.getPreco());
            stmt.setString(3, s.getDescricao());
            stmt.setBoolean(4, s.isUsaCabelo());
            
            
            stmt.executeUpdate();
            JOptionPane.showMessageDialog(null, "Salvo com sucesso!");
            
        }
        catch (SQLException ex) {
            System.out.println(ex);
        } finally {
    }
            ConnectionFactory.closeConnection(con, stmt);
    }
        
        
        










}
